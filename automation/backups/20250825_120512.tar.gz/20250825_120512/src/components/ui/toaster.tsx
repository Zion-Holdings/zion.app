import React from 'react';

export function Toaster() {
  return <div id="toaster" />;
}
