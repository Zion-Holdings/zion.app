export const Toaster = () => {
    return null; // Simple placeholder for now
};
