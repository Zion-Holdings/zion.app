import React, { useState, useMemo } from 'react';
import Layout from '../components/layout/Layout';
import { motion } from 'framer-motion';
import { 
  Rocket, Brain, Atom, Shield, Zap, Target, Users, Star, 
  TrendingUp, Award, Clock, Heart, Lightbulb, Globe, Cpu,
  Database, Lock, Cloud, Settings, Eye, BookOpen, CheckCircle
} from 'lucide-react';
<<<<<<< HEAD
=======
import Layout from '../components/layout/Layout';
import { innovativeRealMicroSaasServices2025 } from '../data/2025-innovative-real-micro-saas-services';
import { innovativeAIServicesEnhanced2025 } from '../data/2025-innovative-ai-services-enhanced';
import { innovativeITServicesEnhanced2025 } from '../data/2025-innovative-it-services-enhanced';
import { emergingTechServicesEnhanced2025 } from '../data/emerging-tech-services';
>>>>>>> origin/cursor/enhance-app-with-new-services-and-futuristic-design-20f7

// Import all service data
import { realMicroSaasServices2025 } from '../data/real-micro-saas-services-2025';
import { realITServices2025 } from '../data/real-it-services-2025';
import { realAIServices2025 } from '../data/real-ai-services-2025';

interface Service {
  id: string;
  name: string;
  tagline: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  popular: boolean;
  icon: string;
  color: string;
  textColor: string;
  link: string;
  category: string;
  realService: boolean;
  technology: string[];
  integrations: string[];
  useCases: string[];
  roi: string;
  competitors: string[];
  marketSize: string;
  growthRate: string;
  customers: number;
  rating: number;
  reviews: number;
}

<<<<<<< HEAD
const ComprehensiveServicesShowcase2025: React.FC = () => {
  const serviceCategories = [
    {
      title: "AI & Consciousness",
      icon:

export default function Comprehensive-services-showcase-2025Page() {
  return (
    <Brain className="w-8 h-8 text-purple-400" />,
      color: "from-purple-500/20 to-purple-600/20",
      borderColor: "border-purple-400/30",
      services: [
        { name: "AI Consciousness Evolution", href: "/ai-consciousness-evolution-2029", featured: true },
        { name: "AI Emotional Intelligence", href: "/ai-emotional-intelligence-training", featured: true },
        { name: "AI Autonomous Research", href: "/ai-autonomous-research-assistant" },
        { name: "AI Predictive Maintenance", href: "/ai-predictive-maintenance-platform" },
        { name: "AI Content Personalization", href: "/ai-content-personalization-engine" },
        { name: "AI Autonomous Ecosystem", href: "/ai-autonomous-ecosystem-manager" }
      ]
    },
    {
      title: "Quantum Technology",
      icon: <Atom className="w-8 h-8 text-blue-400" />,
      color: "from-blue-500/20 to-blue-600/20",
      borderColor: "border-blue-400/30",
      services: [
        { name: "Quantum Neural Networks", href: "/quantum-neural-network-platform", featured: true },
        { name: "Quantum Financial Trading", href: "/quantum-financial-trading", featured: true },
        { name: "Quantum Materials Discovery", href: "/quantum-materials-discovery-platform" },
        { name: "Quantum Bio-Computing", href: "/quantum-bio-computing-platform" },
        { name: "Quantum Internet Security", href: "/quantum-internet-security-platform" },
        { name: "Quantum Cloud Infrastructure", href: "/quantum-cloud-infrastructure-platform" }
      ]
    },
    {
      title: "Space Technology",
      icon: <Rocket className="w-8 h-8 text-cyan-400" />,
      color: "from-cyan-500/20 to-cyan-600/20",
      borderColor: "border-cyan-400/30",
      services: [
        { name: "Space Resource Mining", href: "/space-resource-mining-platform", featured: true },
        { name: "AI-Powered Space Technology", href: "/ai-powered-space-technology" },
        { name: "Space Technology AI Platform", href: "/space-technology-ai-platform" },
        { name: "Space Technology Solutions", href: "/space-technology" }
      ]
    },
    {
      title: "Enterprise IT Solutions",
      icon: <Shield className="w-8 h-8 text-green-400" />,
      color: "from-green-500/20 to-green-600/20",
      borderColor: "border-green-400/30",
      services: [
        { name: "Quantum-Secure Cloud", href: "/quantum-secure-cloud-infrastructure", featured: true },
        { name: "Autonomous IT Operations", href: "/autonomous-it-operations-center", featured: true },
        { name: "Edge Computing Orchestration", href: "/edge-computing-orchestration-platform" },
        { name: "Blockchain Infrastructure", href: "/blockchain-infrastructure-platform" },
        { name: "AI-Powered DevOps", href: "/ai-powered-devops-platform" },
        { name: "Zero Trust Security", href: "/zero-trust-security-platform" }
      ]
    },
    {
      title: "Micro SAAS Solutions",
      icon: <Zap className="w-8 h-8 text-yellow-400" />,
      color: "from-yellow-500/20 to-yellow-600/20",
      borderColor: "border-yellow-400/30",
      services: [
        { name: "AI Customer Success", href: "/ai-customer-success-platform", featured: true },
        { name: "Supply Chain Optimization", href: "/intelligent-supply-chain-optimization", featured: true },
        { name: "HR Analytics Platform", href: "/intelligent-hr-analytics-platform" },
        { name: "Sales Intelligence AI", href: "/ai-sales-intelligence-platform" },
        { name: "Content Automation", href: "/intelligent-content-automation-platform" },
        { name: "Smart CRM Suite", href: "/smart-crm-intelligence-suite" }
      ]
    },
    {
      title: "Industry Solutions",
      icon: <Target className="w-8 h-8 text-pink-400" />,
      color: "from-pink-500/20 to-pink-600/20",
      borderColor: "border-pink-400/30",
      services: [
        { name: "Healthcare Solutions", href: "/healthcare-solutions", featured: true },
        { name: "Financial Solutions", href: "/financial-solutions", featured: true },
        { name: "Government Technology", href: "/government-technology-solutions" },
        { name: "Retail Technology", href: "/retail-technology-solutions" },
        { name: "Manufacturing AI", href: "/manufacturing-ai-solutions" },
        { name: "Education Technology", href: "/education-technology-solutions" }
      ]
=======
const categories = [
  { id: 'all', name: 'All Services', icon: Globe, color: 'from-cyan-500 to-blue-600' },
  { id: 'Micro SAAS', name: 'Micro SAAS', icon: Rocket, color: 'from-teal-500 to-emerald-600' },
  { id: 'AI & Consciousness', name: 'AI & Consciousness', icon: Brain, color: 'from-violet-500 to-purple-600' },
  { id: 'Enterprise IT', name: 'Enterprise IT', icon: Shield, color: 'from-blue-500 to-cyan-600' },
  { id: 'Quantum & Emerging Tech', name: 'Quantum & Emerging Tech', icon: Atom, color: 'from-indigo-500 to-blue-600' }
];

const pricingRanges = [
  { id: 'all', name: 'All Prices', min: 0, max: Infinity },
  { id: 'budget', name: 'Budget ($0 - $100)', min: 0, max: 100 },
  { id: 'mid-range', name: 'Mid-Range ($100 - $500)', min: 100, max: 500 },
  { id: 'premium', name: 'Premium ($500 - $1000)', min: 500, max: 1000 },
  { id: 'enterprise', name: 'Enterprise ($1000+)', min: 1000, max: Infinity }
];

export default function ComprehensiveServicesShowcase2025() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedPricing, setSelectedPricing] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('name');

  const filteredServices = allServices.filter(service => {
    const matchesCategory = selectedCategory === 'all' || service.category === selectedCategory;
    
    // Extract numeric price from string (e.g., "$1,999" -> 1999)
    const priceValue = parseInt(service.price.replace(/[$,]/g, ''));
    const matchesPricing = selectedPricing === 'all' || 
      (priceValue >= pricingRanges.find(p => p.id === selectedPricing)?.min! &&
       priceValue <= pricingRanges.find(p => p.id === selectedPricing)?.max!);
    
    const matchesSearch = service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         service.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         service.category.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesPricing && matchesSearch;
  });

  const sortedServices = [...filteredServices].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'price':
        const priceA = parseInt(a.price.replace(/[$,]/g, ''));
        const priceB = parseInt(b.price.replace(/[$,]/g, ''));
        return priceA - priceB;
      case 'category':
        return a.category.localeCompare(b.category);
      default:
        return 0;
>>>>>>> origin/cursor/enhance-app-with-new-services-and-futuristic-design-20f7
    }
  ];

  const ServiceCard: React.FC<{ service: Service }> = ({ service }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-xl border border-gray-700/50 hover:border-cyan-500/50 rounded-2xl p-6 transition-all duration-300 hover:shadow-2xl hover:shadow-cyan-500/20 group"
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
        <div className="text-3xl">{service.icon}      </div>
        <div>
        <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors duration-300">
              {service.name}
            </h3>
        <p className="text-gray-400 text-sm">{service.tagline}</p>
              </div>
              </div>
        {service.popular && (
          <div className="flex items-center space-x-1 bg-gradient-to-r from-yellow-500 to-orange-500 text-black px-2 py-1 rounded-full text-xs font-semibold">
        <Star className="w-3 h-3 fill-current" />
        <span>Popular</span>
              </div>
        )}
            </div>

      {/* Description */}
      <p className="text-gray-300 mb-4 leading-relaxed">{service.description}</p>

      {/* Price and Rating */}
      <div className="flex items-center justify-between mb-4">
        <div className="text-2xl font-bold text-cyan-400">
          {service.price}
          <span className="text-gray-400 text-sm font-normal">{service.period}</span>
              </div>
        <div className="flex items-center space-x-2">
        <div className="flex items-center space-x-1">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                className={`w-4 h-4 ${i < Math.floor(service.rating) ? 'text-yellow-400 fill-current' : 'text-gray-600'}`} 
              />
            ))}
                </div>
        <span className="text-gray-400 text-sm">({service.reviews})</span>
              </div>
              </div>

      {/* Features */}
      <div className="mb-4">
        <h4 className="text-sm font-semibold text-gray-300 mb-2">Key Features:</h4>
        <div className="grid grid-cols-1 gap-2">
          {service.features.slice(0, 4).map((feature, index) => (
            <div key={index} className="flex items-center space-x-2 text-sm text-gray-400">
        <Check className="w-3 h-3 text-cyan-400" />
        <span>{feature}</span>
              </div>
          ))}
              </div>
              </div>

      {/* Market Info */}
      <div className="grid grid-cols-2 gap-4 mb-4 text-xs">
        <div>
        <span className="text-gray-400">Market Size:</span>
        <div className="text-cyan-400 font-semibold">{service.marketSize}      </div>
              </div>
        <div>
        <span className="text-gray-400">Growth:</span>
        <div className="text-green-400 font-semibold">{service.growthRate}      </div>
              </div>
              </div>

      {/* ROI */}
      <div className="mb-4 p-3 bg-gradient-to-r from-green-500/10 to-teal-500/10 rounded-lg border border-green-500/20">
        <div className="text-sm text-gray-400 mb-1">ROI Impact:      </div>
        <div className="text-green-400 font-semibold text-sm">{service.roi}      </div>
              </div>

      {/* CTA */}
      <div className="flex space-x-3">
        <a
          href={service.link}
          className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-center py-3 px-4 rounded-xl font-semibold hover:from-cyan-600 hover:to-blue-700 transition-all duration-300 transform hover:scale-105"
        >
          Learn More
        </a>
        <button className="px-4 py-3 border border-cyan-400 text-cyan-400 rounded-xl hover:bg-cyan-400 hover:text-black transition-all duration-300">
        <Star className="w-4 h-4" />
        </button>
              </div>
        </motion.div>
  );

  const ServiceList: React.FC<{ service: Service }> = ({ service }) => (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-gradient-to-r from-gray-900/80 to-black/80 backdrop-blur-xl border border-gray-700/50 hover:border-cyan-500/50 rounded-2xl p-6 transition-all duration-300 hover:shadow-2xl hover:shadow-cyan-500/20 group"
    >
        <div className="flex items-center space-x-6">
        <div className="text-4xl">{service.icon}      </div>
        <div className="flex-1">
        <div className="flex items-center justify-between mb-2">
        <h3 className="text-2xl font-bold text-white group-hover:text-cyan-400 transition-colors duration-300">
              {service.name}
            </h3>
            {service.popular && (
              <div className="flex items-center space-x-1 bg-gradient-to-r from-yellow-500 to-orange-500 text-black px-3 py-1 rounded-full text-sm font-semibold">
        <Star className="w-4 h-4 fill-current" />
        <span>Popular</span>
              </div>
            )}
                </div>
        <p className="text-gray-400 text-lg mb-3">{service.tagline}</p>
        <p className="text-gray-300 mb-4 leading-relaxed">{service.description}</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
        <div>
        <span className="text-gray-400">Price:</span>
        <div className="text-cyan-400 font-semibold">{service.price}{service.period}      </div>
              </div>
        <div>
        <span className="text-gray-400">Rating:</span>
        <div className="flex items-center space-x-1">
        <span className="text-yellow-400 font-semibold">{service.rating}/5</span>
        <span className="text-gray-400">({service.reviews})</span>
              </div>
              </div>
        <div>
        <span className="text-gray-400">Market:</span>
        <div className="text-green-400 font-semibold">{service.marketSize}      </div>
              </div>
        <div>
        <span className="text-gray-400">Growth:</span>
        <div className="text-blue-400 font-semibold">{service.growthRate}      </div>
              </div>
              </div>
              </div>
        <div className="flex flex-col space-y-3">
        <a
            href={service.link}
            className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-cyan-600 hover:to-blue-700 transition-all duration-300 transform hover:scale-105"
          >
            Learn More
          </a>
        <button className="px-6 py-3 border border-cyan-400 text-cyan-400 rounded-xl hover:bg-cyan-400 hover:text-black transition-all duration-300">
        <Star className="w-4 h-4" />
        </button>
              </div>
              </div>
        </motion.div>
  );

  return (
    <Layout>
        <div className="min-h-screen bg-gradient-to-br from-black via-gray-900/20 to-black">
        {/* Hero Section */}
        <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
        <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
<<<<<<<< HEAD:temp_components/comprehensive-services-showcase-2025.tsx.backup.1755992101
<<<<<<< HEAD
              <div className="flex justify-center mb-6">
                <div className="p-4 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 rounded-full">
                  <Star className="w-12 h-12 text-yellow-400" />
=======
              <option value="name">Sort by Name</option>
              <option value="price">Sort by Price</option>
              <option value="category">Sort by Category</option>
            </select>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-2">
              Showing {sortedServices.length} of {allServices.length} Services
            </h2>
            <p className="text-gray-400">
              {selectedCategory !== 'all' && `Category: ${selectedCategory}`}
              {selectedPricing !== 'all' && ` • Price Range: ${pricingRanges.find(p => p.id === selectedPricing)?.name}`}
              {searchQuery && ` • Search: "${searchQuery}"`}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {sortedServices.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="group"
              >
                <div className="relative p-6 rounded-2xl bg-gradient-to-br from-gray-800/50 to-gray-900/50 border border-gray-700/50 hover:border-cyan-500/50 transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/10 h-full">
                  {/* Category Badge */}
                  <div className="absolute top-4 right-4">
                    <div className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${getCategoryColor(service.category)} text-white`}>
                      <Globe className="w-3 h-3" />
                      {service.category}
                    </div>
                  </div>

                  {/* Service Icon */}
                  <div className="mb-6">
                    <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-r ${getCategoryColor(service.category)} group-hover:scale-110 transition-transform duration-300`}>
                      {React.createElement(getCategoryIcon(service.category), { className: "w-8 h-8 text-white" })}
                    </div>
                  </div>

                  {/* Service Info */}
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-cyan-400 transition-colors duration-300 line-clamp-2">
                    {service.name}
                  </h3>
                  <p className="text-gray-300 text-sm mb-4 leading-relaxed line-clamp-3">
                    {service.description}
                  </p>

                  {/* Pricing */}
                  <div className="mb-4">
                    <div className="text-2xl font-bold text-cyan-400">
                      {service.price}
                      <span className="text-sm text-gray-400 font-normal">{service.period}</span>
                    </div>
                    <div className="text-xs text-gray-500">Starting from</div>
                  </div>

                  {/* Features Preview */}
                  <div className="mb-6">
                    <div className="text-sm text-gray-400 mb-2">Key Features:</div>
                    <div className="space-y-1">
                      {service.features.slice(0, 3).map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center gap-2 text-xs text-gray-300">
                          <CheckCircle className="w-3 h-3 text-cyan-400 flex-shrink-0" />
                          <span className="line-clamp-1">{feature}</span>
                        </div>
                      ))}
                      {service.features.length > 3 && (
                        <div className="text-xs text-gray-500">
                          +{service.features.length - 3} more features
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="mb-6">
                    <div className="flex flex-wrap gap-1">
                      {service.features.slice(0, 3).map((feature, featureIndex) => (
                        <span
                          key={featureIndex}
                          className="px-2 py-1 bg-gray-800 text-gray-300 text-xs rounded-md"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Market Info */}
                  <div className="mb-6 text-xs text-gray-400">
                    <div className="flex justify-between items-center mb-2">
                      <span>Market Size:</span>
                      <span className="text-cyan-400 font-medium">{service.marketSize}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Target Audience:</span>
                      <span className="text-gray-300">{service.targetAudience.split(',')[0]}...</span>
                    </div>
                  </div>

                  {/* CTA Button */}
                  <Link href={`/services/${service.id}`}>
                    <button className="w-full py-3 px-6 bg-gradient-to-r from-gray-700 to-gray-800 text-white font-semibold rounded-xl hover:from-cyan-600 hover:to-blue-600 transition-all duration-300 hover:scale-105 hover:shadow-lg group">
                      <span className="flex items-center justify-center gap-2">
                        Learn More
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                      </span>
                    </button>
                  </Link>
>>>>>>> origin/cursor/enhance-app-with-new-services-and-futuristic-design-20f7
                </div>
========
        <div className="flex justify-center mb-6">
        <div className="p-4 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 rounded-full">
        <Star className="w-12 h-12 text-yellow-400" />
>>>>>>>> a8e698aa2a3f65846644470f902bc566286f2743:pages.disabled/comprehensive-services-showcase-2025.tsx
              </div>
              </div>
        <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-purple-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent mb-6">
                Comprehensive Services Showcase 2025
              </h1>
        <p className="text-xl md:text-2xl text-white/80 max-w-4xl mx-auto mb-8">
                Discover our complete portfolio of cutting-edge technology solutions, 
                from AI consciousness evolution to quantum computing and space technology.
              </p>
        <div className="flex flex-wrap justify-center gap-4">
        <button className="px-8 py-4 bg-gradient-to-r from-purple-500 to-cyan-500 text-white font-semibold rounded-lg hover:from-purple-600 hover:to-cyan-600 transition-all duration-300 transform hover:scale-105">
                  Explore All Services
                </button>
        <button className="px-8 py-4 border border-purple-400/30 text-purple-400 font-semibold rounded-lg hover:bg-purple-400/10 transition-all duration-300">
                  View Pricing
                </button>
              </div>
        </motion.div>
              </div>
        </section>

        {/* Services Categories */}
        <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
        <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Complete Service Portfolio
              </h2>
        <p className="text-xl text-white/70 max-w-3xl mx-auto">
                Our comprehensive suite of services covers every aspect of modern technology, 
                from artificial intelligence to quantum computing and beyond.
              </p>
        </motion.div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {serviceCategories.map((category, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className={`p-8 bg-gradient-to-br ${category.color} backdrop-blur-sm rounded-xl border ${category.borderColor} hover:border-opacity-50 transition-all duration-300`}
                >
        <div className="flex items-center mb-6">
                    {category.icon}
                    <h3 className="text-2xl font-bold text-white ml-3">{category.title}</h3>
              </div>
        <div className="space-y-3">
                    {category.services.map((service, serviceIndex) => (
                      <div key={serviceIndex} className="flex items-center justify-between">
        <a
                          href={service.href}
                          className="text-white/80 hover:text-white transition-colors flex items-center"
                        >
                          {service.featured && (
                            <Star className="w-4 h-4 text-yellow-400 mr-2" />
                          )}
                          {service.name}
                        </a>
                        {service.featured && (
                          <span className="text-xs bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-2 py-1 rounded-full">
                            Featured
                          </span>
                        )}
                            </div>
                    ))}
                        </div>
        </motion.div>
              ))}
                  </div>
              </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
        <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Ready to Transform Your Business?
              </h2>
        <p className="text-xl text-white/70 mb-8">
                Choose from our comprehensive portfolio of cutting-edge solutions 
                and take your business to the next level of technological innovation.
              </p>
        <div className="flex flex-wrap justify-center gap-4">
        <button className="px-8 py-4 bg-gradient-to-r from-purple-500 to-cyan-500 text-white font-semibold rounded-lg hover:from-purple-600 hover:to-cyan-600 transition-all duration-300 transform hover:scale-105">
                  Get Started Today
                </button>
        <button className="px-8 py-4 border border-purple-400/30 text-purple-400 font-semibold rounded-lg hover:bg-purple-400/10 transition-all duration-300">
                  Schedule Consultation
                </button>
              </div>
        </motion.div>
              </div>
        </section>

        {/* CTA Section */}
        <section className="px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
        <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="bg-gradient-to-r from-cyan-500/10 via-blue-500/10 to-purple-500/10 backdrop-blur-xl border border-cyan-500/30 rounded-3xl p-12"
            >
        <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                Ready to Transform Your Business?
              </h2>
        <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                Let our team of experts help you choose the perfect solutions for your business needs
              </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <a
                  href="/contact"
                  className="px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-xl hover:from-cyan-600 hover:to-blue-700 transition-all duration-300 transform hover:scale-105"
                >
                  Get Started Today
                </a>
        <a
                  href="tel:+13024640950"
                  className="px-8 py-4 border-2 border-cyan-400 text-cyan-400 font-semibold rounded-xl hover:bg-cyan-400 hover:text-black transition-all duration-300"
                >
                  Call +1 302 464 0950
                </a>
              </div>
        </motion.div>
              </div>
        </section>
        </main>
        </Layout>
  );
}

  );
}