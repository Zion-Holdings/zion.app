export default function ServerErrorPage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      Something went wrong.
    </div>
  );
}