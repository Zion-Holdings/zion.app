import React from 'react';
import Head from 'next/head';
  return (

export default function It-onsite-servicesPage() {
  return (
    <>
              <Head>
        <title>it-onsite-services - Zion App</title>
        <meta name="description" content="it-onsite-services page" />
              </Head>
              <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">it-onsite-services</h1>
        <p className="text-lg mb-4">This page is under construction.</p>
        <div className="mt-4">
        <a href="/" className="text-blue-600 hover:underline">
            ← Back to Home</a>
              </div>
              </div>
        </>
  );

  );
}